# MAGAYE AI v0.3

A phone-friendly educational dashboard prototype for EUR/USD, GBP/USD, XAU/USD and BTC/USD.

## Included
- Dark mobile-first dashboard
- Market and timeframe selectors (M5, M15, M30, H1, H4, Multiple)
- Plain-language RSI, MACD and moving-average learning guide
- Basic PWA manifest and offline cache

## Important limitations
This is a front-end prototype. It has **no live price feed**, no Exness/MetaTrader 5 connection, no AI model and no order execution. It must not be treated as financial advice or a trading signal. Never put broker passwords, API secrets or account credentials in this repository.

## Publish with GitHub Pages
1. Open your MAGAYE-AI repository on GitHub.
2. Tap **Add file → Upload files**.
3. Upload `index.html`, `manifest.json`, `sw.js` and `README.md` from this folder.
4. Tap **Commit changes**.
5. Open **Settings → Pages**.
6. Under Build and deployment, choose **Deploy from a branch**.
7. Choose branch `main` and folder `/(root)`, then save.
8. Wait for GitHub Pages to publish and open the URL shown on that page.

## Next stage
Add a properly licensed market-data provider, display the provider and update timestamp, then build and test indicator calculations against historical/demo data. Keep the project read-only and educational.
